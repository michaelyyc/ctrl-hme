float floatFromSerial(int delimiter);
int intFromSerial(int delimiter);
bool boolFromSerial();