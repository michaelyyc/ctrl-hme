float floatFromSerial1(int delimiter);
int intFromSerial1(int delimiter);
bool boolFromSerial1();
int boolIntFromSerial1();