//From Garage node

#define garage_doorStatus 		'a'
#define garage_tempZone1		'b'
#define garage_tempZone2		'c'
#define garage_error			'd'
#define garage_autoCloseEnabled  'e'

//From basement node

#define bsmt_tempZone1			'f'
#define bsmt_tempZone2			'g'
#define bsmt_tempZone3			'h'

//Fron bedroom node

#define bdrm_temp				'i'
#define bdrm_outlet1Status		'j'
